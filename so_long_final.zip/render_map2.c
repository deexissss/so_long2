/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   render_map2.c                                      :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: tjehaes <tjehaes@student.42luxembourg >    +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/10/17 15:10:01 by tjehaes           #+#    #+#             */
/*   Updated: 2024/10/17 15:43:51 by tjehaes          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "so_long.h"

char	**parse_map(int fd, t_data *data)
{
	char	*map_str;

	map_str = get_map(fd);
	if (!map_str)
		return (NULL);
	data->map = ft_split(map_str, '\n');
	free(map_str);
	check_content(data);
	if (!(check_format(data->map)))
		return (free_map(data));
	if (!(check_line(data->map[0], data->content.wall)))
		return (free_map(data));
	return (parse_core(1, data));
}

char	**map_core(char **str, t_data *data)
{
	int		fd;

	data->map = NULL;
	if (ft_strchr(str[1], ".ber") == 0)
	{
		ft_printf("Error\nNo correct format map found\n");
		return (0);
	}
	fd = open(str[1], O_RDONLY);
	if (fd < 0)
	{
		ft_printf("Error\nFailed to open file\n");
		return (0);
	}
	data->map = parse_map(fd, data);
	return (check_map_content(data));
}

char	**check_map_content(t_data *data)
{
	if (data->content.count_c == 0 || data->content.count_e != 1
		|| data->content.count_p != 1)
	{
		free_map(data);
		ft_printf("Error\nNeed 1 Player/Exit and min 1 Object\n");
		return (0);
	}
	return (data->map);
}
/*
char	*free_buff(char *buff)
{
	free(buff);
	ft_printf("Error\nWrong lecture map\n");
	return (NULL);
}*/
